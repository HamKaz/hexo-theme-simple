
使用に当たって
-----------
フォントをインストールして頂くとパソコンのワープロ、グラフィックソフトなどのアプリケーションでこのフォントを使って自由にデザイン、印刷することができます。


概要
-----------

装甲明朝は以下の派生フォントです。
「源ノ明朝 (Source Han Serif)」



インストール
-----------
1.フォントをダウンロードしたら圧縮されたファイルを解凍します。
まず+Lhaca、StuffIt Expander、WinRAR、Lhaplus等の解凍ソフトを使用し
解凍してフォントファイルにして下さい。
2.フォントをパソコンにインストールします。
以下からお使いのパソコンのインストール方法に従ってください。
 
Windows7、8、10以降でのフォントのインストール
https://www.flopdesign.com/windows8-fontinstall.html
 
Mac OS Xでのフォントのインストール
https://www.flopdesign.com/macosx-font-install.html
 

ライセンス
----------
このフォントのライセンスは、
フォントは以下のライセンスに準じます。
SIL Open Font License 1.1

SIL Open Font License 1.1 の説明は同梱の LICENSE_OFL.txtをお読み下さい
日本語訳は以下になります。
http://osdn.jp/projects/opensource/wiki/SIL_Open_Font_License_1.1

■ 頒布元

フロップデザイン
https://www.flopdesign.com/


■ 改変元


装甲明朝は以下のフォントを改変して制作しました。
制作に関わる全ての方に深くお礼申し上げます。

源ノ明朝 (Source Han Serif)
https://source.typekit.com/source-han-serif/jp/



